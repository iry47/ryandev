/* Change this file to get your personal Porfolio */

// Website related settings
const settings = {
  isSplash: true, // Change this to true if you want to use the splash screen.
  useCustomCursor: true, // Change this to false if you want the good'ol cursor
};

//Home Page
const greeting = {
  title: "Welcome 🙏🏽",
  title2: "Ryan",
  logo_name: "ryan.h()",
  // nickname: "harry / picleric",
  full_name: "Ryan Headley",
  subTitle:
    "Data Scientist, Full Stack Developer, World Traveller, Life Long Learner.",
  resumeLink:
  "https://www.linkedin.com/in/ryanheadley-dev/",
  mail: "mailto:ryan.headley@me.com",
};

const socialMediaLinks = {
  /* Your Social Media Link */
  github: "https://github.com/iry47/",
  linkedin: "https://www.linkedin.com/in/ryanheadley-dev/",
  gmail: "ryan.headley@me.com",
  facebook: "",
  instagram: "https://www.instagram.com/iry47/",
};

const skills = {
  data: [
    {
      title: "Travel",
      fileName: "CloudInfraImg",
      skills: [
        "🌎 Extensive travel throughout multiple continents",
        "🌍 Polyglot: English, French, Spanish, Portuguese",
        "🌏 Experience in hospitality, sports, permaculture",
      ],
      softwareSkills: [
        {
          skillName: "Palm",
          fontAwesomeClassname: "emojione:palm-tree",
          style: {
            color: "#6863A6",
          },
        },
        {
          skillName: "Mountain",
          fontAwesomeClassname: "emojione:mountain",
          style: {
            color: "#FFCA28",
          },
        },
      ],
    },
    {
      title: "Computer Science",
      fileName: "FullStackImg",
      skills: [
        "⚡ Creating a variety of machine learning and other A.I models",
        "⚡ Engineering the full data pipeline from quality to observability",
        "⚡ Develop highly interactive User Interfaces and Backend for web applications",
        "⚡ Integration of third party services such as AWS",
      ],
      softwareSkills: [
        {
          skillName: "Python",
          fontAwesomeClassname: "simple-icons:python",
          style: {
            color: "#3776AB",
          },
        },
        {
          skillName: "Apache",
          fontAwesomeClassname: "simple-icons:apache",
          style: {
            color: "#CA1A22",
          },
        },
        {
          skillName: "ReactJS",
          fontAwesomeClassname: "simple-icons:react",
          style: {
            color: "#61DAFB",
          },
        },
        {
          skillName: "NodeJS",
          fontAwesomeClassname: "simple-icons:node-dot-js",
          style: {
            color: "#339933",
          },
        },
        {
          skillName: "Flask",
          fontAwesomeClassname: "simple-icons:flask",
          style: {
            color: "#000000",
          },
        },
        {
          skillName: "Linux",
          fontAwesomeClassname: "simple-icons:linux",
          style: {
            color: "#000000",
          },
        },
        {
          skillName: "MySQL",
          fontAwesomeClassname: "simple-icons:mysql",
          style: {
            color: "#4479A1",
          },
        },
        
        {
          skillName: "Git",
          fontAwesomeClassname: "simple-icons:git",
          style: {
            color: "#E94E32",
          },
        },
        {
          skillName: "C",
          fontAwesomeClassname: "simple-icons:c",
          style: {
            color: "#E94E32",
          },
        },
        
        {
          skillName: "AWS",
          fontAwesomeClassname: "simple-icons:amazonaws",
          style: {
            color: "#FF9900",
          },
        },
        {
          skillName: "PostgreSQL",
          fontAwesomeClassname: "simple-icons:postgresql",
          style: {
            color: "#336791",
          },
        },
        {
          skillName: "MongoDB",
          fontAwesomeClassname: "simple-icons:mongodb",
          style: {
            color: "#47A248",
          },
        },
        {
          skillName: "Docker",
          fontAwesomeClassname: "simple-icons:docker",
          style: {
            color: "#1488C6",
          },
        },
        {
          skillName: "HTML5",
          fontAwesomeClassname: "simple-icons:html5",
          style: {
            color: "#E34F26",
          },
        },
      ],
    },
  ],
};

const degrees = {
  degrees: [
    {
      title: "EPITECH",
      subtitle: "Master in Artificial Intelligence",
      logo_path: "epitech_logo.png",
      alt_name: "European Institue of Technology",
      duration: "Paris, France 2020 - 2022",
      descriptions: [
        "⚡  A Masters of Computer Science with a specialty in A.I. in a co-op system, meaning I studied and worked professionally in parallel. Checkout out my experience and projects pages for more info! .",
        // "⚡ I have studied core subjects like Data Structures, DBMS, Networking, Security, etc.",
        // "⚡ I have also completed various online courses for Backend , Web , Mobile App Development, etc.",
        // "⚡ I have implemented several projects based on what I've leart under my Computer Engineering course. ",
      ],
      website_link: "https://www.srmist.edu.in/",
    },
    {
      title: "Queen's University",
      subtitle: "Bachelors in Computer Science",
      logo_path: "queens_logo.png",
      alt_name: "Queen's University",
      duration: "Kingston, Canada 2014 - 2025",
      descriptions: [
        "A second Bachelor's in Computer Science.",
        // "⚡ I have studied core subjects like Data Structures, DBMS, Networking, Security, etc.",
        // "⚡ I have also completed various online courses for Backend , Web , Mobile App Development, etc.",
        // "⚡ I have implemented several projects based on what I've leart under my Computer Engineering course. ",
      ],
      website_link: "https://www.epitech.eu/",
    },
    {
      title: "Queen's University",
      subtitle: "Bachelors in Mechanical Engineering",
      logo_path: "queens_logo.png",
      alt_name: "Queen's University",
      duration: "Kingston, Canada 2010 - 2014",
      descriptions: [
        "My first Bachelor's degree in Mechanical Engineering.",
        // "⚡ I have studied core subjects like Data Structures, DBMS, Networking, Security, etc.",
        // "⚡ I have also completed various online courses for Backend , Web , Mobile App Development, etc.",
        // "⚡ I have implemented several projects based on what I've leart under my Computer Engineering course. ",
      ],
      website_link: "https://www.queensu.ca/",
    },
  ],
};

const certifications = {
  certifications: [
    {
      title: "AWS Cloud Practitioner",
      subtitle: "Amazon Web Services",
      logo_path: "aws_logo.png",
      certificate_link:
        "https://drive.google.com/file/d/1r0hYt8Pp0N0u_4Tg-poMF1Qv3LkoKVAP/view",
      alt_name: "AWS Cloud Practitioner",
      // color_code: "#2AAFED",
      color_code: "#2AAFED",
    },
    // {
    //   title: "A300: Atlas Security",
    //   subtitle: "MongoDB University",
    //   logo_path: "mongo.png",
    //   certificate_link:
    //     "https://drive.google.com/file/d/12u_tkvhgB-K2TIm-RDdJOwYbQ9ccqiqA/view?usp=sharing",
    //   alt_name: "MongoDB University",
    //   // color_code: "#F6B808",
    //   color_code: "#47A048",
    // },
    // {
    //   title: "MLH Local Hack Day: Build",
    //   subtitle: "Major League Hacking",
    //   logo_path: "mlh-logo.svg",
    //   certificate_link:
    //     "https://drive.google.com/file/d/1ws7g2Oepu76vDFir6SvR_emFAMSkB2ZQ/view?usp=sharing",
    //   alt_name: "Google",
    //   color_code: "#fe0037",
    // },
    
    // color_code: "#8C151599",
    // color_code: "#7A7A7A",
    // color_code: "#0C9D5899",
    // color_code: "#C5E2EE",
    // color_code: "#ffc475",
    // color_code: "#g",
    // color_code: "#ffbfae",
    // color_code: "#fffbf3",
    // color_code: "#b190b0",
  ],
};

// Travel Page
const blogs = {
  blogs: [
    {
      title: "Travel the Amazon river by boat",
      description: "The Amazon doesn't have many roads, so boats are the main method of transportation. Find out what is required and what to expect to explore the lungs of the earth!",
      image: "amazon-river-cruise.jpg",
      url: "",
      color_code: "",
    },
    {
      title: "Work a ski season in the Alps",
      description: "Explore working a season in one of the most known ski locations in the world.",
      image: "champagny-crew.jpg",
      url: "",
      color_code: "",
    },
    {
      title: "Benefits of staying in hostels",
      description: "How staying in Hostels can help every traveller connect to and learn the local culture.",
      image: "banana-group.jpg",
      url: "",
      color_code: "",
    },
  ]
}

// Experience Page
const experience = {
  title: "Experience",
  subtitle: "Work, Internship and Volunteership",
  description:
    "I've gained a wide array of experience between full stack development and data science.",
  header_image_path: "experience.svg",
  sections: [
    {
      title: "Work Experience",
      experiences: [
        {
          title: "Data Engineer and Full Stack",
          company: "Quant AI Lab",
          company_url: "https://quant.global/",
          logo_path: "quant_logo.png",
          duration: "Sept 2021 - Current",
          location: "Paris, France",
          description: `
          Having two primary job titles, my primary tasks alternate between creating the front and backend of the company's applications, and working with 
          data science to improve the analysis and machine learning models connected to the applications. In addition I worked through a wide array of
          organisational, operational and roadmapping tasks since I arrived at the creation of the team in France, which since has over doubled in size.
          `,
          // "I worked on the Dashboard project which helps users track their activities while using Walo Application. I also worked on Ocean Inventory Application and it's Admin panel Backend as well as on Ocean Inventory Admin Front-end using React and also worked on Walo Admin Backend.",
          color: "#0071C5",
        },
        {
          title: "A.I Engineer and Full Stack",
          company: "Pomelo Factory",
          company_url: "https://pomelofactory.fr/",
          logo_path: "pomelo_logo.webp",
          duration: "Oct 2020 - Aug 2021",
          location: "Paris, France",
          description: `Pomelo Factory creates marketing videos for companies of all sizes and also innovates in the sector of automating the video editing process for video editors thanks to A.I. (NLP).
          I’m responsable for the entire application, working on the front, back and all models of transcription.
          `,
          // "Created Front end of Yearn Financial Mutual Funds website. also degined simple web application for better user experience, designed DB Schemas as well.",
          color: "#ee3c26",
        },
        {
          title: "CTO / Solutions Architect",
          company: "Kidwelcome",
          company_url: "https://kidwelcome.com/",
          logo_path: "kidwelcome_logo.jpg",
          duration: "Feb 2019 - Dec 2020",
          location: "Paris, France",
          description: `
          Kidwelcome is a search engine for kid-friendly restaurants and hotels. Being one of two assiociates, 
          I was responsable for the technology of the company, both back end and front end of the web application.
          `,
          // "Created Front end of Yearn Financial Mutual Funds website. also degined simple web application for better user experience, designed DB Schemas as well.",
          color: "#ee3c26",
        },
        {
          title: "Full Stack",
          company: "Freelance",
          company_url: "https://ryanheadley.net/",
          logo_path: "logo_ryan.png",
          duration: "Sep 2018 - Oct 2020",
          location: "Remote",
          description: `While travelling through Europe and South America, I was working as a remote full stack developper. 
          Focusing primarily on website, my work alternated between CMS sites such as wordpress to personalized websites from the ground up.
          `,
          // "Created Front end of Yearn Financial Mutual Funds website. also degined simple web application for better user experience, designed DB Schemas as well.",
          color: "#ee3c26",
        },
      ],
    },
    // {
    //   title: "Volunteerships",
    //   experiences: [
    //     {
    //       title: "R&D Member",
    //       company: "Webarch Club",
    //       company_url: "https://www.webarchsrm.com/",
    //       logo_path: "Webarch.jfif",
    //       duration: "Mar 2020 - Nov 2020",
    //       location: "SRM IST Kattankulathur",
    //       description:
    //         "Member responsibilities were to help students in project planning, review issues and pull requests, ensure smooth progress and help juniors out in their difficulties.",
    //       color: "#4285F4",
    //     },
        
    //   ],
    // },
  ],
};

// Projects Page
const projectsHeader = {
  title: "Projects",
  description:
    "The projects listed year are a brief resume of the types of problems that were solved during the past years of my Masters in A.I.",
  avatar_image_path: "projects_image.svg",
};

// Contact Page
const contactPageData = {
  contactSection: {
    title: "Contact Me",
    profile_image_path: "ryan_face_afro.png",
    description:
      "Always happy to chat 😁 so please don't hesitate to send me a message in one of the channels below ! ",
  },
  blogSection: {
    title: "Blogs",
    subtitle:
      "I don't blog frequently but when I do something awesome, I do try to document it so it can be helpful to others.",
    link: "https://medium.com/@vedanshvijay/",
    avatar_image_path: "blogs_image.svg",
  },
};

const projects = {
  data: [
    {
      id: "0",
      name: "Taxi Driver",
      url: "https://github.com/iry47/taxi_driver",
      description:
        "Use Reinforcement Learning to beat the Taxi-v3 environement in the OpenAI gym library.",
      languages: [
        {
          name: "Python",
          iconifyClass: "logos-python",
        },
        {
          name: "Jupyter Notebook",
          iconifyClass: "logos-jupyter",
        },
      ],
    },
    {
      id: "1",
      name: "Sensor Sensei",
      url: "https://github.com/iry47/sensor_sensei",
      description:
        "Assemble an air monitoring IoT kit to record data and automatically transmit the information to the local server and then to the opensource Sensor Community project.",
      languages: [
        {
          name: "C++",
          iconifyClass: "logos:c-plusplus",
        },
        {
          name: "IoT",
          iconifyClass: "eos-icons:iot",
        },
      ],
    },
    {
      id: "2",
      name: "Recommender",
      url: "https://github.com/iry47/recommender",
      description:
        "Take a database of client product purchases and create a recommendation system that suits an individual client's preferences.",
      languages: [
        {
          name: "Python",
          iconifyClass: "logos-python",
        },
        {
          name: "Flask",
          iconifyClass: "cib-flask",
        },
        {
          name: "HTML5",
          iconifyClass: "vscode-icons:file-type-html",
        },
        {
          name: "CSS3",
          iconifyClass: "vscode-icons:file-type-css",
        },
        {
          name: "ReactJS",
          iconifyClass: "logos-react",
        },
      ],
    },
    {
      id: "3",
      name: "Pathfinder",
      url: "https://github.com/iry47/taxi_driver",
      description:
        "Create an application that takes a user's vocal request as input, and outputs the fastest train travel between the requested departure and destination, if in France.",
      languages: [
        {
          name: "Python",
          iconifyClass: "logos-python",
        },
        {
          name: "Flask",
          iconifyClass: "cib-flask",
        },
        {
          name: "HTML5",
          iconifyClass: "vscode-icons:file-type-html",
        },
        {
          name: "CSS3",
          iconifyClass: "vscode-icons:file-type-css",
        },
        {
          name: "JavaScript",
          iconifyClass: "logos-javascript",
        },
        
      ],
    },
    {
      id: "4",
      name: "VM",
      url: "https://github.com/iry47/taxi_driver",
      description:
        "Automatically create a virtual machine that launches and connects an Angular frontend, Java backend application and GitLab repository.",
      languages: [
        {
          name: "Python",
          iconifyClass: "logos-python",
        },
        {
          name: "Jupyter Notebook",
          iconifyClass: "logos-jupyter",
        },
      ],
    },
    {
      id: "3",
      name: "Zoidberg",
      url: "https://github.com/iry47/zoidberg",
      description: "Create a machine learning model that takes X-rays of the thorax and determines the presence of pneumonia.",
      languages: [
        {
          name: "Python",
          iconifyClass: "logos-python",
        },
        {
          name: "Jupyter Notebook",
          iconifyClass: "logos-jupyter",
        },
      ],
    },
  ],
};

export {
  settings,
  greeting,
  socialMediaLinks,
  blogs,
  skills,
  degrees,
  certifications,
  experience,
  projectsHeader,
  contactPageData,
  projects,
};
