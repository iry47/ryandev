import React from "react";
import "./MapComponent.css";
import { OverlayTrigger, Tooltip } from "react-bootstrap";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import icon from "../../assets/images/marker.png";

function MapComponent(props) {
  const markers = props.markers;

  const markerIcon = new L.Icon({
    iconUrl: icon,
    iconSize: [25, 35],
    iconAnchor: [5, 30]
})
  function MapView() {
    let map = useMap();
    map.setView([20.0, -30.0], map.getZoom());
     //Sets geographical center and zoom for the view of the map
    return null;
  }

  return (
    <div>
      <div className="map-main-div">
      <MapContainer
      classsName="map"
      center={[0.0, 0.0]}
      zoom={2}
      scrollWheelZoom={true}
    >
      <TileLayer
        attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> 
        contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {markers.map((marker) => {
        return (
          <Marker icon={markerIcon} position={[marker.geometry.coordinates[1], marker.geometry.coordinates[0]]}>
            <Popup>
              {marker.properties.Title}
              <br></br>
              <a href={marker.properties["Google Maps URL"]}>View in Google Maps</a>
            </Popup>
          </Marker>
        );
      })}
      <MapView />
    </MapContainer>
      </div>
    </div>
  );
}

export default MapComponent;
